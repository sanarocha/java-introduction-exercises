public class Uni5Exe03 {
    public static void main(String[] args) {

        double soma = 0;

        for(int cont = 1; cont <= 100; cont++){
            soma += (1.0/cont);
        }
        System.out.println(soma);

    }
    
}
